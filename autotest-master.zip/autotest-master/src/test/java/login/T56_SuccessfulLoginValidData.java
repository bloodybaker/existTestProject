package login;

import com.creditkasa.core.utils.Constants;
import com.creditkasa.core.utils.Generator;
import com.creditkasa.core.utils.SelenideTools;
import org.json.simple.parser.ParseException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class T56_SuccessfulLoginValidData {

    @BeforeTest
    public void setup() {
        SelenideTools.openUrl(Constants.LANDING);
    }

    @Test(description = "Sign in with a valid data")
    public void signUp() {

    }
}
