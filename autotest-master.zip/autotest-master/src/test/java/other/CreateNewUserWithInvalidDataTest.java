package other;

import com.creditkasa.core.base.BaseTest;
import com.creditkasa.core.utils.Constants;
import com.creditkasa.core.utils.Generator;
import com.creditkasa.core.utils.SelenideTools;
import com.creditkasa.entities.User;
import com.creditkasa.pages.backoffice.PagesBack;
import com.creditkasa.pages.frontoffice.PagesFront;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CreateNewUserWithInvalidDataTest extends BaseTest {

    private User user;

    @BeforeTest
    public void createUser() throws ParseException, java.text.ParseException {
        user = Generator.genUser();
    }

    @Test(description = "Create new user with a invalid data")
    public void signUpIncorrectFields() {
        Assert.assertTrue(PagesFront.loginPage().isPhoneInputFieldPresent());
        Assert.assertTrue(PagesFront.loginPage().isSignInButtonPresent());
        Assert.assertTrue(PagesFront.loginPage().isSignUpLinkPresent());

        PagesFront.loginPage().clickSignUP();
        Assert.assertTrue(PagesFront.signUpPage().isFirsNamePresent());
        Assert.assertTrue(PagesFront.signUpPage().isLastNamePresent());
        Assert.assertTrue(PagesFront.signUpPage().isPhoneNumberPresent());
        Assert.assertTrue(PagesFront.signUpPage().isNextButtonPresent());

        Assert.assertTrue(PagesFront.signUpPage().isSimpleContactFormExist());
        PagesFront.signUpPage().fillContactFields(user);
        SelenideTools.openUrlInNewWindow(Constants.BACK_OFFICE_URL);
        SelenideTools.switchToLastTab();
        PagesBack.loginPage().login(Constants.BACK_LOGIN,Constants.BACK_PASSWORD);
        PagesBack.navBar().openNotifications();
        PagesBack.notificationPage().openCurrentNotificationPage(user.getPhoneNumber());
        String otp = PagesBack.currentNotificationPage().getOTP();
        SelenideTools.closeCurrentTab();
        SelenideTools.switchTo().window(0);

        Assert.assertTrue(PagesFront.signUpPage().isBoxesOTPExists());
        PagesFront.signUpPage().inputOTP(otp);

        Assert.assertTrue(PagesFront.signUpPage().isThirdNamePresent());
        Assert.assertTrue(PagesFront.signUpPage().isDayPresent());
        Assert.assertTrue(PagesFront.signUpPage().isMonthPresent());
        Assert.assertTrue(PagesFront.signUpPage().isYearPresent());
        Assert.assertTrue(PagesFront.signUpPage().isPassportButtonPresent());
        Assert.assertTrue(PagesFront.signUpPage().isEmailPresent());
        Assert.assertTrue(PagesFront.signUpPage().isSalaryPresent());
        Assert.assertTrue(PagesFront.signUpPage().isIdentificationCodePresent());

        Assert.assertTrue(PagesFront.signUpPage().isPersonalDataFieldsExist());
        PagesFront.signUpPage().fillPersonalData(user);
        PagesFront.newLoanPage().closeDialog();
        PagesFront.newLoanPage().clickNewLoan();
        PagesFront.newLoanPage().fillLoanInfo();
    }
}