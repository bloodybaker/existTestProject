package other;

import com.creditkasa.core.utils.Database;
import com.creditkasa.core.utils.Generator;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Test;

import javax.xml.crypto.Data;
import java.sql.SQLException;

public class GeneratorsTest {
    @Test
    public void testNumber() throws ParseException, java.text.ParseException, SQLException {
        //System.out.println(Generator.genMobilePhone());
        //RandomDataAPIConnector.getData();
        for(int i = 1; i <= 1000; i++){
            if(i % 10 == 0) System.out.println("Created: "+ i + " users");
            Database.getInstance().addUser(Generator.genUser());
        }
        Database.getInstance().selectAll();
    }
}
