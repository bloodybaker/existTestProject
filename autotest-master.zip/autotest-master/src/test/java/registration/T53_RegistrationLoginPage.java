package registration;

import com.creditkasa.core.base.BaseTest;
import com.creditkasa.core.config.SelenideConfig;
import com.creditkasa.core.utils.Constants;
import com.creditkasa.core.utils.Generator;
import com.creditkasa.core.utils.SelenideTools;
import com.creditkasa.entities.User;
import com.creditkasa.pages.backoffice.PagesBack;
import com.creditkasa.pages.frontoffice.PagesFront;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class T53_RegistrationLoginPage extends BaseTest {
    private User user;

    @Parameters({"browser"})
    @BeforeTest
    public void createUser(String browser) throws ParseException, java.text.ParseException {
        user = Generator.genUser();
        startInBrowser(browser);
    }

    @Test(description = "Create new user with a valid data")
    public void signUp() {
        PagesFront.loginPage().clickSignUP();
        PagesFront.signUpPage().fillContactFields(user);

        SelenideTools.openUrlInNewWindow(Constants.BACK_OFFICE_URL);
        SelenideTools.switchToLastTab();
        PagesBack.loginPage().login(Constants.BACK_LOGIN,Constants.BACK_PASSWORD);
        PagesBack.navBar().openNotifications();
        PagesBack.notificationPage().openCurrentNotificationPage(user.getPhoneNumber());
        String otp = PagesBack.currentNotificationPage().getOTP();
        SelenideTools.closeCurrentTab();
        SelenideTools.switchTo().window(0);

        PagesFront.signUpPage().inputOTP("A000");
        Assert.assertTrue(PagesFront.signUpPage().isOtpErrorPresent());
        SelenideTools.sleep(30);

        PagesFront.signUpPage().inputOTP("A"+Generator.genInt(100,999));
        Assert.assertTrue(PagesFront.signUpPage().isOtpErrorPresent());

        SelenideTools.sleep(120);
        PagesFront.signUpPage().resendCode();

        SelenideTools.openUrlInNewWindow(Constants.BACK_OFFICE_URL);
        SelenideTools.switchToLastTab();
        PagesBack.navBar().openNotifications();
        PagesBack.notificationPage().openCurrentNotificationPage(user.getPhoneNumber());
        String newOTP = PagesBack.currentNotificationPage().getOTP();
        SelenideTools.closeCurrentTab();
        SelenideTools.switchTo().window(0);

        PagesFront.signUpPage().inputOTP(newOTP);

        SelenideTools.sleep(10);
        Assert.assertTrue(PagesFront.signUpPage().isThirdNamePresent());
        Assert.assertTrue(PagesFront.signUpPage().isDayPresent());
        Assert.assertTrue(PagesFront.signUpPage().isMonthPresent());
        Assert.assertTrue(PagesFront.signUpPage().isYearPresent());
        Assert.assertTrue(PagesFront.signUpPage().isPassportButtonPresent());
        Assert.assertTrue(PagesFront.signUpPage().isEmailPresent());
        Assert.assertTrue(PagesFront.signUpPage().isSalaryPresent());
        Assert.assertTrue(PagesFront.signUpPage().isIdentificationCodePresent());
    }
}
