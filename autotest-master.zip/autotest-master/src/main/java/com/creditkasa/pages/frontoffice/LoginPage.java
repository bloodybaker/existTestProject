package com.creditkasa.pages.frontoffice;

import com.creditkasa.core.base.PageTools;
import org.openqa.selenium.By;

public class LoginPage extends PageTools {

    private By phoneInputField = By.xpath("//input");
    private By signInButton = By.xpath("//button[@form='login-form']");
    private By signUpLink = By.xpath("//main//a");

    public void clickSignUP(){
        waitForElementVisibility(signUpLink);
        click(signUpLink);
    }


    public boolean isPhoneInputFieldPresent() {
        return isElementVisible(phoneInputField);
    }

    public boolean isSignInButtonPresent() {
        return isElementVisible(signInButton);
    }

    public boolean isSignUpLinkPresent() {
        return isElementVisible(signUpLink);
    }
}