package com.creditkasa.pages.backoffice;

import com.creditkasa.core.base.PageTools;
import org.openqa.selenium.By;

public class CurrentNotificationPage extends PageTools {
    private By otpMessage = By.xpath("//pre");

    public String getOTP(){
        waitForElementVisibility(otpMessage);
        return getElementText(otpMessage);
    }
}
