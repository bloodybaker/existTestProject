package com.creditkasa.pages.banks.privat;

import com.creditkasa.core.base.PageTools;
import com.creditkasa.core.utils.Constants;
import com.creditkasa.pages.banks.Loginable;
import org.openqa.selenium.By;

public class PrivatAuthPage extends PageTools implements Loginable {
    private By phoneInput = By.xpath("//input[@data-qa-node='login-number']");
    private By passwordInput = By.xpath("//input[@type='password']");
    private By confirmButton = By.xpath("//button");

    @Override
    public void auth(){
        typePhoneInput(Constants.PRIVAT_LOGIN);
        typePasswordInput(Constants.PRIVAT_PASSWORD);
        clickConfirmButton();
    }

    private void typePhoneInput(String text) {
        waitForElementVisibility(phoneInput);
        type(text, phoneInput);
    }

    private void typePasswordInput(String text) {
        waitForElementVisibility(passwordInput);
        type(text, passwordInput);
    }

    private void clickConfirmButton() {
        waitForElementClickable(confirmButton);
        click(confirmButton);
    }
}
