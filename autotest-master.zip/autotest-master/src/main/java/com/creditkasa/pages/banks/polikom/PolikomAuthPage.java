package com.creditkasa.pages.banks.polikom;

import com.creditkasa.core.base.PageTools;
import com.creditkasa.core.utils.Constants;
import com.creditkasa.pages.banks.Loginable;
import org.openqa.selenium.By;

public class PolikomAuthPage extends PageTools implements Loginable {

    private By loginInput = By.xpath("//input[@id='auth_inp_login']");
    private By passwordInput = By.xpath("//input[@id='auth_inp_pass']");
    private By confirmButton = By.xpath("//button");

    @Override
    public void auth(){
        typeLoginInput(Constants.POLIKOM_LOGIN);
        typePasswordInput(Constants.POLIKOM_PASSWORD);
        clickConfirmButton();
    }


    private void typeLoginInput(String text) {
        waitForElementVisibility(loginInput);
        type(text, loginInput);
    }

    private void typePasswordInput(String text) {
        waitForElementVisibility(passwordInput);
        type(text, passwordInput);
    }

    private void clickConfirmButton() {
        waitForElementClickable(confirmButton);
        click(confirmButton);
    }
}
