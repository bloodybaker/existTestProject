package com.creditkasa.pages.backoffice;

public class PagesBack {
    private static LoginPage loginPage;
    private static HomePage homePage;
    private static NotificationPage notificationPage;
    private static CurrentNotificationPage currentNotificationPage;
    private static NavBar navBar;

    public static NotificationPage notificationPage(){
        if(notificationPage == null){
            notificationPage = new NotificationPage();
        }
        return notificationPage;
    }
    public static CurrentNotificationPage currentNotificationPage(){
        if(currentNotificationPage == null){
            currentNotificationPage = new CurrentNotificationPage();
        }
        return currentNotificationPage;
    }

    public static LoginPage loginPage() {
        if (loginPage == null) {
            loginPage = new LoginPage();
        }
        return loginPage;
    }

    public static HomePage homePage(){
        if(homePage == null){
            homePage = new HomePage();
        }
        return homePage;
    }
    public static NavBar navBar(){
        if(navBar == null){
            navBar = new NavBar();
        }
        return navBar;
    }
}
