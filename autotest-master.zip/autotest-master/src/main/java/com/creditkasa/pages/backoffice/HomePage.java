package com.creditkasa.pages.backoffice;

import com.creditkasa.core.base.PageTools;
import org.openqa.selenium.By;

public class HomePage extends PageTools {



}
