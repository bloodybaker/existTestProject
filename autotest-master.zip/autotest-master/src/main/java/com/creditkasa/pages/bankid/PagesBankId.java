package com.creditkasa.pages.bankid;

public class PagesBankId {

    private static BanksList banksList;

    public static BanksList banksList(){
        if(banksList == null){
            banksList = new BanksList();
        }
        return banksList;
    }

}
