package com.creditkasa.pages.banks;


import com.creditkasa.pages.banks.polikom.PolikomAuthPage;
import com.creditkasa.pages.banks.privat.PrivatAuthPage;
import com.creditkasa.pages.banks.privat.PrivatConfirmPage;
import com.creditkasa.pages.banks.vostok.VostokAuthPage;

public class PagesBanks {

    private static PrivatAuthPage privatAuthPage;
    private static PrivatConfirmPage privatConfirmPage;

    private static VostokAuthPage vostokAuthPage;

    private static PolikomAuthPage polikomAuthPage;

    public static PrivatAuthPage privatAuthPage(){
        if(privatAuthPage == null){
            privatAuthPage = new PrivatAuthPage();
        }
        return privatAuthPage;
    }

    public static PrivatConfirmPage privatConfirmPage(){
        if(privatConfirmPage == null){
            privatConfirmPage = new PrivatConfirmPage();
        }
        return privatConfirmPage;
    }

    public static VostokAuthPage vostokAuthPage(){
        if(vostokAuthPage == null){
            vostokAuthPage = new VostokAuthPage();
        }
        return vostokAuthPage;
    }

    public static PolikomAuthPage polikomAuthPage(){
        if(polikomAuthPage == null){
            polikomAuthPage = new PolikomAuthPage();
        }
        return polikomAuthPage;
    }
}
