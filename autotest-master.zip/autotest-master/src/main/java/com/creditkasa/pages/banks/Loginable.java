package com.creditkasa.pages.banks;

public interface Loginable {
   void auth();
}
