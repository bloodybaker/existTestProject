package com.creditkasa.pages.backoffice;

import com.creditkasa.core.base.PageTools;
import org.openqa.selenium.By;

public class NotificationPage extends PageTools {

    private By rawByPhoneNum = By.xpath("//a[@href='tel:+38%s']/../..");

    public void openCurrentNotificationPage(String number){
        waitForElementVisibility(rawByPhoneNum,number);
        click(rawByPhoneNum,number);
    }

}
