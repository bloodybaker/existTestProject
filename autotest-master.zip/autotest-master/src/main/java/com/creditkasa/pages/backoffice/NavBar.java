package com.creditkasa.pages.backoffice;

import com.creditkasa.core.base.PageTools;
import org.openqa.selenium.By;

public class NavBar extends PageTools {

    private By stat = By.xpath("//span[contains(text(),'Статистика') or contains(text(),'Dashboard')]");
    private By creditApplications = By.xpath("//span[contains(text(),'Кредитные заявки') " +
            "or contains(text(),'Credit Applications')]");
    private By under = By.xpath("//span[contains(text(),'Андеррайтинг')]");
    private By credits = By.xpath("//span[contains(text(),'Кредиты') or contains(text(),'Credits')]");
    private By borrowers = By.xpath("//span[contains(text(),'Клиенты') or contains(text(),'Borrowers')]");
    private By templates = By.xpath("//span[contains(text(),'Шаблоны') or contains(text(),'Templates')]");
    private By products = By.xpath("//span[contains(text(),'Продукты') or contains(text(),'Products')]");

    //user management block
    private By userManagement = By.xpath("//span[contains(text(),'Пользователи и роли') " +
            "or contains(text(),'User Management')]");
    private By users = By.xpath("//a[contains(text(),'Пользователи') or contains(text(),'Users')]");
    private By roles = By.xpath("//a[contains(text(),'Роли') or contains(text(),'Roles')]");

    //risks block
    private By risksManagement = By.xpath("//span[contains(text(),'Управление рисками') " +
            "or contains(text(),'Risks Management')]");
    private By blackList = By.xpath("//a[contains(text(),'Добавить в черный список') or contains(text(),'Blacklist')]");
    private By monitoring = By.xpath("//a[contains(text(),'Финансовый мониторинг')]");

    //marketing block
    private By marketing = By.xpath("//span[contains(text(),'Маркетинг') or contains(text(),'Marketing')]");
    private By promoCodes = By.xpath("//a[contains(text(),'Промокоды') or contains(text(),'Promo Codes')]");
    private By affiliates = By.xpath("//a[contains(text(),'Аффилиаты') or contains(text(),'Affiliates')]");
    private By viewAllLeads = By.xpath("//a[contains(text(),'Все лиды')]");
    private By leads = By.xpath("//a[contains(text(),'Лиды') or contains(text(),'Leads')]");

    //business block
    private By businessProcesses = By.xpath("//span[contains(text(),'Бизнес-процессы') " +
            "or contains(text(),'Business Processes')]");
    private By deployments = By.xpath("//a[contains(text(),'Деплойменты')]");

    // logs block
    private By logs = By.xpath("//span[contains(text(),'Журналы') or contains(text(),'Logs')]");
    private By transactions = By.xpath("//a[contains(text(),'Транзакции') or contains(text(),'Transactions')]");
    private By notifications = By.xpath("//a[contains(text(),'Нотификации') or contains(text(),'Notifications')]");
    private By uploadsBKI = By.xpath("//a[contains(text(),'Выгрузки в БКИ') or contains(text(),'BKI uploads')]");

    //settings block
    private By settings = By.xpath("//span[contains(text(),'Настройки') or contains(text(),'Settings')]");
    private By batchOperations = By.xpath("//a[contains(text(),'Массовые операции') " +
            "or contains(text(),'Batch operations')]");
    private By underWritingSettins = By.xpath("//a[contains(text(),'Настройки панели андеррайтера')]");
    private By blacklistSettings = By.xpath("//a[contains(text(),'Настройки черных списков')]");



    public void openNotifications(){
        waitForElementClickable(logs);
        click(logs);
        waitForElementClickable(notifications);
        click(notifications);
    }

    public void openDashBoard(){
        waitForElementClickable(stat);
        click(stat);
    }

    public void openCreditApplications(){
        waitForElementClickable(creditApplications);
        click(creditApplications);
    }

    public void openUnderwriting(){
        waitForElementClickable(under);
        click(under);
    }

    public void openCredits(){
        waitForElementClickable(credits);
        click(credits);
    }

    public void openBorrowers(){
        waitForElementClickable(borrowers);
        click(borrowers);
    }

    public void openTemplates(){
        waitForElementClickable(templates);
        click(templates);
    }

    public void openProducts(){
        waitForElementClickable(products);
        click(products);
    }

    public void openUsers(){
        waitForElementClickable(userManagement);
        click(userManagement);
        waitForElementClickable(users);
        click(users);
    }

    public void openRoles(){
        waitForElementClickable(userManagement);
        click(userManagement);
        waitForElementClickable(roles);
        click(roles);
    }

    public void openBlackList(){
        waitForElementClickable(risksManagement);
        click(risksManagement);
        waitForElementClickable(blackList);
        click(blackList);
    }

    public void openMonitoring(){
        waitForElementClickable(risksManagement);
        click(risksManagement);
        waitForElementClickable(monitoring);
        click(monitoring);
    }

    public void openPromoCodes(){
        waitForElementClickable(marketing);
        click(marketing);
        waitForElementClickable(promoCodes);
        click(promoCodes);
    }

    public void openAffiliates(){
        waitForElementClickable(marketing);
        click(marketing);
        waitForElementClickable(affiliates);
        click(affiliates);
    }

    public void openAllLeads(){
        waitForElementClickable(marketing);
        click(marketing);
        waitForElementClickable(viewAllLeads);
        click(viewAllLeads);
    }

    public void openLead(){
        waitForElementClickable(marketing);
        click(marketing);
        waitForElementClickable(leads);
        click(leads);
    }

    public void openDeployments(){
        waitForElementClickable(businessProcesses);
        click(businessProcesses);
        waitForElementClickable(deployments);
        click(deployments);
    }

    public void openTransactions(){
        waitForElementClickable(logs);
        click(logs);
        waitForElementClickable(transactions);
        click(transactions);
    }

    public void openUploadsBKI(){
        waitForElementClickable(logs);
        click(logs);
        waitForElementClickable(uploadsBKI);
        click(uploadsBKI);
    }
    
    public void openBatchOperations(){
        waitForElementClickable(settings);
        click(settings);
        waitForElementClickable(batchOperations);
        click(batchOperations);
    }

    public void openUnderwritingSettings(){
        waitForElementClickable(settings);
        click(settings);
        waitForElementClickable(underWritingSettins);
        click(underWritingSettins);
    }

    public void openBlackListSettings(){
        waitForElementClickable(settings);
        click(settings);
        waitForElementClickable(blacklistSettings);
        click(blacklistSettings);
    }
}
