package com.creditkasa.pages.frontoffice;

import com.creditkasa.core.base.PageTools;
import com.creditkasa.core.utils.Generator;
import org.openqa.selenium.By;

public class NewLoanPage extends PageTools {

    private By mainButton = By.xpath("//main//button");
    private By closeDialogButton = By.xpath("(//mat-dialog-container//button)[1]");

    private By time = By.xpath("(//section[@class='control']//input)[1]");
    private By amount = By.xpath("(//section[@class='control']//input)[2]");

    private By nicknameButton = By.xpath("//ck-user-menu//button");
    private By logoutButton = By.xpath("//button[@role='menuitem']");

    public void closeDialog(){
        waitForElementClickable(closeDialogButton);
        click(closeDialogButton);
    }

    public void clickNewLoan(){
        waitForElementClickable(mainButton);
        click(mainButton);
    }

    public void fillLoanInfo(){
        waitForElementVisibility(time);
        type(String.valueOf(Generator.genInt(5,30)),time);
        waitForElementVisibility(amount);
        type(String.valueOf(Generator.genInt(1000,2000)),amount);

    }

    public boolean isMainButtonPresent() {
        return isElementVisible(mainButton);
    }

    public boolean isCloseDialogButtonPresent() {
        return isElementVisible(closeDialogButton);
    }

    public boolean isTimePresent() {
        return isElementVisible(time);
    }

    public boolean isAmountPresent() {
        return isElementVisible(amount);
    }

    public void logout(){
        waitForElementClickable(nicknameButton);
        click(nicknameButton);
        waitForElementClickable(logoutButton);
        click(logoutButton);
    }
}
