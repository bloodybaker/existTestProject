package com.creditkasa.pages.backoffice;

import com.creditkasa.core.base.PageTools;
import com.creditkasa.core.utils.SelenideTools;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

public class LoginPage extends PageTools {

    private By usernameField = By.xpath("//input[@name='username']");
    private By passwordField = By.xpath("//input[@name='password']");
    private By loginButton = By.xpath("//button");

    public void login(String username, String password) {
        waitForElementVisibility(usernameField);
        type(username,usernameField);
        waitForElementVisibility(passwordField);
        type(password,passwordField);
        waitForElementClickable(loginButton);
        click(loginButton);
    }

    public boolean isUsernameFieldPresent() {
        return isElementVisible(usernameField);
    }

    public boolean isPasswordFieldPresent() {
        return isElementVisible(passwordField);
    }

    public boolean isLoginButtonPresent() {
        return isElementVisible(loginButton);
    }

}
