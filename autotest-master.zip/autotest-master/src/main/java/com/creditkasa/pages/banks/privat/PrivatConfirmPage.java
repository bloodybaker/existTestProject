package com.creditkasa.pages.banks.privat;

import com.creditkasa.core.base.PageTools;
import org.openqa.selenium.By;

public class PrivatConfirmPage extends PageTools {
    private By acceptButton = By.xpath("//button[@class='confirm']");
    private By cancelButton = By.xpath("//button[@class='cancel']");

    public void accept(){
        waitForElementClickable(acceptButton);
        click(acceptButton);
    }

    public void cancel(){
        waitForElementClickable(cancelButton);
        click(cancelButton);
    }
}
