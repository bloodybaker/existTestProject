package com.creditkasa.pages.banks.vostok;

import com.creditkasa.core.base.PageTools;
import com.creditkasa.core.utils.Constants;
import com.creditkasa.pages.banks.Loginable;
import org.openqa.selenium.By;

public class VostokAuthPage extends PageTools implements Loginable {
    private By phoneInput = By.xpath("//input[@id='loginPhone']");
    private By passwordInput = By.xpath("//input[@id='loginPassword']");
    private By otpInput = By.xpath("//input[@id='loginOTP']");

    private By nextButton = By.xpath("//input[@class='jsRealButton']");

    @Override
    public void auth() {
        typePhoneInput(Constants.VOSTOK_LOGIN);
        clickNextButton();
        typePasswordInput(Constants.VOSTOK_PASSWORD);
        clickNextButton();
        typeOtpInput(Constants.VOSTOK_OTP);
        clickNextButton();
    }

    private void typePhoneInput(String text) {
        waitForElementVisibility(phoneInput);
        type(text, phoneInput);
    }

    private void typePasswordInput(String text) {
        waitForElementVisibility(passwordInput);
        type(text, passwordInput);
    }

    private void typeOtpInput(String text) {
        waitForElementVisibility(otpInput);
        type(text, otpInput);
    }

    private void clickNextButton() {
        waitForElementVisibility(nextButton);
        click(nextButton);
    }
}
