package com.creditkasa.pages.frontoffice;

import com.creditkasa.core.base.PageTools;
import org.openqa.selenium.By;

public class LandingPage extends PageTools {

    private By signUpButton = By.xpath("//a[@class='register']");
    private By loginButton = By.xpath("//a[@class='login']");
    private By amountInput = By.xpath("//input[@id='amount_input']");
    private By daysInput = By.xpath("//input[@id='days_input']");

    public boolean isSignUpButtonPresent() {
        return isElementVisible(signUpButton);
    }

    public boolean isLoginButtonPresent() {
        return isElementVisible(loginButton);
    }

    public boolean isAmountInputPresent() {
        return isElementVisible(amountInput);
    }

    public boolean isDaysInputPresent() {
        return isElementVisible(daysInput);
    }

    public void clickSignUpButton() {
        waitForElementClickable(signUpButton);
        click(signUpButton);
    }

    public void clickLoginButton() {
        waitForElementClickable(loginButton);
        click(loginButton);
    }


    public void typeAmountInput(String text) {
        waitForElementVisibility(amountInput);
        type(text, amountInput);
    }

    public void typeDaysInput(String text) {
        waitForElementVisibility(daysInput);
        type(text, daysInput);
    }
}
