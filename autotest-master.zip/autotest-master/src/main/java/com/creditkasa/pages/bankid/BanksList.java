package com.creditkasa.pages.bankid;

import com.creditkasa.core.base.PageTools;
import org.openqa.selenium.By;

public class BanksList  extends PageTools {

    private By vostok = By.xpath("(//a[@aria-label='Bank Vostok'])[1]");
    private By polikom = By.xpath("(//a[@aria-label='Policombank'])[1]");
    private By pb = By.xpath("(//a[@aria-label='Privatbank'])[1]");


    public boolean isVostokPresent() {
        return isElementVisible(vostok);
    }

    public boolean isPolikomPresent() {
        return isElementVisible(polikom);
    }

    public boolean isPbPresent() {
        return isElementVisible(pb);
    }


    public void clickVostok() {
        waitForElementClickable(vostok);
        click(vostok);
    }

    public void clickPolikom() {
        waitForElementClickable(polikom);
        click(polikom);
    }

    public void clickPb() {
        waitForElementClickable(pb);
        click(pb);
    }
}
