package com.creditkasa.pages.frontoffice;

import com.creditkasa.core.base.PageTools;
import com.creditkasa.core.utils.Generator;
import com.creditkasa.entities.User;
import org.openqa.selenium.By;

public class SignUpPage extends PageTools {

    private By privatBank = By.xpath("(//lib-bank-id//button)[1]");
    private By bankId = By.xpath("(//lib-bank-id//button)[2]");

    private By lastName = By.xpath("(//main//input)[1]");
    private By firsName = By.xpath("(//main//input)[2]");
    private By phoneNumber = By.xpath("(//main//input)[3]");
    private By nextButton = By.xpath("//button[@form='contact-form']");

    private By resendOTP = By.xpath("(//lib-resend-sms-btn//span)[1]");
    private By changeNumber = By.xpath("//button//span[contains(text(),'Изменить номер')]");

    private By otpBoxFirst = By.xpath("(//lib-otp//input)[1]");
    private By otpBoxSecond = By.xpath("(//lib-otp//input)[2]");
    private By otpBoxThird = By.xpath("(//lib-otp//input)[3]");
    private By otpBoxFourth = By.xpath("(//lib-otp//input)[4]");

    private By passportButton = By.xpath("(//ck-options//button)[1]");
    private By idCardButton = By.xpath("(//ck-options//button)[2]");

    private By thirdName = By.xpath("//lib-input[@data-id='middleName']//input");
    private By day = By.xpath("//mat-select[@name='day']");
    private By month = By.xpath("//mat-select[@name='month']");
    private By year = By.xpath("//mat-select[@name='year']");
    private By valueSelector = By.xpath("(//span[@class='mat-option-text'])[%s]");
    private By serialValue = By.xpath("//lib-input[@data-id='passportSeries']//input");
    private By passportNumber = By.xpath("//lib-input[@data-id='passportNumber']//input");
    private By identificationCode = By.xpath("//lib-input[@data-id='inn']//input");
    private By email = By.xpath("//lib-input[@data-id='email']//input");
    private By salary = By.xpath("//lib-input[@data-id='salary']//input");
    private By nextToCabinetButton = By.xpath("//button[@form='personal-data-form']");


    //errorBlock

    private By lastNameError = By.xpath("//lib-input[@data-id='lastName']//mat-error");
    private By firstNameError = By.xpath("//lib-input[@data-id='firstName']//mat-error");
    private By phoneNumberError = By.xpath("//lib-input[@data-id='mobilePhone']//mat-error");

    private By otpError = By.xpath("//mat-error");

    private By thirdNameError = By.xpath("//lib-input[@data-id='middleName']//mat-error");
    private By passportDataError = By.xpath("//lib-input[@data-id='passportNumber']//mat-error");

    private By identificationCodeError = By.xpath("//lib-input[@data-id='inn']//mat-error");
    private By emailError = By.xpath("//lib-input[@data-id='email']//mat-error");

    private By idCardError = By.xpath("//lib-input[@data-id='idCardNumber']//mat-error");


    public boolean isSimpleContactFormExist(){
        return isElementVisible(lastName)
                && isElementVisible(firsName)
                && isElementVisible(phoneNumber)
                && isElementClickable(nextButton);
    }

    public void switchToIdCardMethod(){
        waitForElementClickable(idCardButton);
        click(idCardButton);
    }
    public void switchToPassportMethod(){
        waitForElementClickable(passportButton);
        click(passportButton);
    }

    public void fillContactFields(User user){
        type(user.getLastName(),lastName);
        type(user.getFirstName(),firsName);
        type(user.getPhoneNumber(),phoneNumber);
        waitForElementClickable(nextButton);
        click(nextButton);
    }

    public boolean isBoxesOTPExists(){
        return isElementVisible(otpBoxFirst)
                && isElementVisible(otpBoxSecond)
                && isElementVisible(otpBoxThird)
                && isElementVisible(otpBoxFourth);
    }

    public void inputOTP(String otpCode){
        typeWithoutWipe(String.valueOf(otpCode.charAt(0)),otpBoxFirst);
        typeWithoutWipe(String.valueOf(otpCode.charAt(1)),otpBoxSecond);
        typeWithoutWipe(String.valueOf(otpCode.charAt(2)),otpBoxThird);
        typeWithoutWipe(String.valueOf(otpCode.charAt(3)),otpBoxFourth);
    }

    public boolean isPersonalDataFieldsExist(){
        waitForElementVisibility(thirdName);
        return isElementPresent(thirdName)
                && isElementPresent(day)
                && isElementPresent(month)
                && isElementPresent(year)
                && isElementPresent(serialValue)
                && isElementPresent(passportNumber)
                && isElementPresent(identificationCode)
                && isElementPresent(email)
                && isElementPresent(salary)
                && isElementPresent(nextToCabinetButton);
    }

    public void fillPersonalData(User user){
        logInfo(user.toString());
        waitForElementVisibility(thirdName);
        type(user.getThirdName(),thirdName);
        waitForElementVisibility(day);
        click(day);
        waitForElementVisibility(valueSelector,user.getDayOfBirth());
        click(valueSelector, user.getDayOfBirth());
        waitForElementVisibility(month);
        click(month);
        waitForElementVisibility(valueSelector,user.getMonthOfBirth());
        click(valueSelector, user.getMonthOfBirth());
        waitForElementVisibility(year);
        click(year);
        waitForElementVisibility(valueSelector,String.valueOf(2021-Integer.parseInt(user.getYearOfBirth())));
        click(valueSelector, String.valueOf(2021-Integer.parseInt(user.getYearOfBirth())));
        waitForElementVisibility(serialValue);
        type(user.getSerialValue(), serialValue);
        waitForElementVisibility(passportNumber);
        type(user.getPassportNumber(), passportNumber);
        waitForElementVisibility(identificationCode);
        type(user.getIdentificationCode(),identificationCode);
        waitForElementVisibility(email);
        type(user.getEmail(),email);
        waitForElementVisibility(salary);
        type(String.valueOf(Generator.genInt(5000,13000)),salary);
        waitForElementClickable(nextToCabinetButton);
        click(nextToCabinetButton);
    }

    public boolean isLastNamePresent() {
        return isElementVisible(lastName);
    }

    public boolean isFirsNamePresent() {
        return isElementVisible(firsName);
    }

    public boolean isPhoneNumberPresent() {
        return isElementVisible(phoneNumber);
    }

    public boolean isNextButtonPresent() {
        return isElementVisible(nextButton);
    }

    public boolean isOtpBoxFirstPresent() {
        return isElementVisible(otpBoxFirst);
    }

    public boolean isOtpBoxSecondPresent() {
        return isElementVisible(otpBoxSecond);
    }

    public boolean isOtpBoxThirdPresent() {
        return isElementVisible(otpBoxThird);
    }

    public boolean isOtpBoxFourthPresent() {
        return isElementVisible(otpBoxFourth);
    }

    public boolean isPassportButtonPresent() {
        return isElementVisible(passportButton);
    }

    public boolean isIdCardButtonPresent() {
        return isElementVisible(idCardButton);
    }

    public boolean isThirdNamePresent() {
        return isElementVisible(thirdName);
    }

    public boolean isDayPresent() {
        return isElementVisible(day);
    }

    public boolean isMonthPresent() {
        return isElementVisible(month);
    }

    public boolean isYearPresent() {
        return isElementVisible(year);
    }

    public boolean isValueSelectorPresent() {
        return isElementVisible(valueSelector);
    }

    public boolean isSerialValuePresent() {
        return isElementVisible(serialValue);
    }

    public boolean isPassportNumberPresent() {
        return isElementVisible(passportNumber);
    }

    public boolean isIdentificationCodePresent() {
        return isElementVisible(identificationCode);
    }

    public boolean isEmailPresent() {
        return isElementVisible(email);
    }

    public boolean isSalaryPresent() {
        return isElementVisible(salary);
    }

    public boolean isNextToCabinetButtonPresent() {
        return isElementVisible(nextToCabinetButton);
    }

    public boolean isLastNameErrorPresent() {
        return isElementVisible(lastNameError);
    }

    public boolean isFirstNameErrorPresent() {
        return isElementVisible(firstNameError);
    }

    public boolean isPhoneNumberErrorPresent() {
        return isElementVisible(phoneNumberError);
    }

    public boolean isThirdNameErrorPresent() {
        return isElementVisible(thirdNameError);
    }

    public boolean isPassportDataErrorPresent() {
        return isElementVisible(passportDataError);
    }

    public boolean isIdentificationCodeErrorPresent() {
        return isElementVisible(identificationCodeError);
    }

    public boolean isEmailErrorPresent() {
        return isElementVisible(emailError);
    }

    public boolean isIdCardErrorPresent() {
        return isElementVisible(idCardError);
    }


    public boolean isResendOTPPresent() {
        return isElementVisible(resendOTP);
    }

    public boolean isChangeNumberPresent() {
        return isElementVisible(changeNumber);
    }
    public boolean isOtpErrorPresent() {
        return isElementVisible(otpError);
    }

    public void resendCode() {
        waitForElementClickable(resendOTP);
        click(resendOTP);
    }

    public void selectPrivatBank() {
        waitForElementClickable(privatBank);
        click(privatBank);
    }
    public void selectBankId() {
        waitForElementClickable(bankId);
        click(bankId);
    }
}
