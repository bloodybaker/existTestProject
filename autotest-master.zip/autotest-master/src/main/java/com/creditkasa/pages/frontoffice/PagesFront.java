package com.creditkasa.pages.frontoffice;

import com.creditkasa.core.allure.AllureLogger;

public class PagesFront extends AllureLogger {
    /**
     * Pages
     */
    private static LoginPage loginPage;
    private static SignUpPage signUpPage;
    private static NewLoanPage newLoanPage;
    private static LandingPage landingPage;

    /**
     * This function return an instance of `LoginPage`
     */
    public static LoginPage loginPage() {
        if (loginPage == null) {
            loginPage = new LoginPage();
        }
        return loginPage;
    }
    /**
     * This function return an instance of `SignUpPage`
     */
    public static SignUpPage signUpPage() {
        if (signUpPage == null) {
            signUpPage = new SignUpPage();
        }
        return signUpPage;
    }

    public static NewLoanPage newLoanPage() {
        if (newLoanPage == null) {
            newLoanPage = new NewLoanPage();
        }
        return newLoanPage;
    }

    public static LandingPage landingPage(){
        if(landingPage == null){
            landingPage = new LandingPage();
        }
        return landingPage;
    }
}