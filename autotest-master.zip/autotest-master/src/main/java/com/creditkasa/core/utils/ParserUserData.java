package com.creditkasa.core.utils;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ParserUserData {
    private static JSONParser parser = new JSONParser();

    public static String[] getUserData(String json) throws ParseException {
        String[] userData = new String[3];
        JSONObject obj = (JSONObject)parser.parse(json);
        userData[0] = obj.get("LastName").toString();
        userData[1] = obj.get("FirstName").toString();
        userData[2] = obj.get("FatherName").toString();
        return userData;
    }

}
