package com.creditkasa.core.utils;

import com.creditkasa.entities.User;
import org.sqlite.JDBC;

import java.sql.*;

public class Database {
    private static final String CON_STR = "jdbc:sqlite::resource:autotest.db";
    private Connection connection;
    private static Database instance = null;

    public static synchronized Database getInstance() throws SQLException {
        if (instance == null)
            instance = new Database();
        return instance;
    }

    private Database() throws SQLException {
        DriverManager.registerDriver(new JDBC());
        this.connection = DriverManager.getConnection(CON_STR);
    }

    public void addUser(User user) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement
                ("INSERT INTO 'users' VALUES((SELECT MAX(id) FROM 'users')+1,?,?,?,?,?,?,?,?,?,?,?)");
        preparedStatement.setString(1,user.getFirstName());
        preparedStatement.setString(2,user.getLastName());
        preparedStatement.setString(3,user.getThirdName());
        preparedStatement.setString(4,user.getPhoneNumber());
        preparedStatement.setString(5,user.getEmail());
        preparedStatement.setString(6,user.getIdentificationCode());
        preparedStatement.setString(7,user.getDayOfBirth());
        preparedStatement.setString(8,user.getMonthOfBirth());
        preparedStatement.setString(9,user.getYearOfBirth());
        preparedStatement.setString(10,user.getSerialValue());
        preparedStatement.setString(11,user.getPassportNumber());
        preparedStatement.executeUpdate();
    }

    public User selectRandomUser() throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement
                ("Select ('first_name','last_name','third_name'," +
                        "'phone_number','email','identification_code'," +
                        "'day', 'month','year'," +
                        "'serial_value','passport_number') from 'users' where 'id' = ?");
        preparedStatement.setInt(1,Generator.genInt(1,1000));
        ResultSet set = preparedStatement.executeQuery();
        if (set.next()){
            return new User(
                    set.getString(1),
                    set.getString(2),
                    set.getString(3),
                    set.getString(4),
                    set.getString(5),
                    set.getString(6),
                    set.getString(7),
                    set.getString(8),
                    set.getString(9),
                    set.getString(10),
                    set.getString(11));
        }
        return null;
    }
    public User selectUserByPhone(String phone) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement
                ("Select ('first_name','last_name','third_name'," +
                        "'phone_number','email','identification_code'," +
                        "'day', 'month','year'," +
                        "'serial_value','passport_number') from 'users' where 'phone_number' = ?");
        preparedStatement.setString(1,phone);
        ResultSet set = preparedStatement.executeQuery();
        if (set.next()){
            return new User(
                    set.getString(1),
                    set.getString(2),
                    set.getString(3),
                    set.getString(4),
                    set.getString(5),
                    set.getString(6),
                    set.getString(7),
                    set.getString(8),
                    set.getString(9),
                    set.getString(10),
                    set.getString(11));
        }
        return null;
    }
    public void selectAll() throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement
                ("Select * from 'users'");
        ResultSet set = preparedStatement.executeQuery();
        while (set.next()){
            System.out.println(set.getString(2) + " " + set.getString(3));
        }
    }

}
