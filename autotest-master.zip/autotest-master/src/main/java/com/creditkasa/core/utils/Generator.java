package com.creditkasa.core.utils;

import com.creditkasa.entities.User;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.parser.ParseException;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Generator {

    public static int genInt(int from, int to) {
        return new Random().nextInt((to - from) + 1) + from;
    }

    public static String getRandomStringNumber() {
        return RandomStringUtils.randomNumeric(10);
    }

    public static String genString(int length) {
        return RandomStringUtils.randomAlphabetic(length);
    }
    public static String genRandomSerial(){
        String cyrillicCharacters = "АБВГДЕЖЗИКЛМНОПРСТУФХЧЭЮЯ";
        String result = StringUtils.EMPTY;
        for(int i = 0; i < 2; i++) {
         result += String.valueOf(cyrillicCharacters.charAt(new Random().nextInt(cyrillicCharacters.length())));
        }
        return result;
    }

    public static String getRandomStringNumber(int length) {
        return RandomStringUtils.randomNumeric(length);
    }

    public static String genAccountNumber() {
        return genInt(1, 9) + RandomStringUtils.randomNumeric(11);
    }

    public static String genMobilePhone() {
        String[] operatorCodes = new String[]
                {"039","067","068","096","097","098","050","066","095","099","063","097","091","092","094"};
        return operatorCodes[new Random().nextInt(operatorCodes.length)] + getRandomStringNumber(7);
    }

    public static String genEmail() {
        return "auto"+genNumInRange(0,10) + genString(6) + "@mail.com";
    }

    public static float genFloat(double from, double to, int precision) {
        float number = genFloat(from, to);
        return (float) Math.round(number * Math.pow(10, precision)) / (float) Math.pow(10, precision);
    }

    private static float genFloat(double from, double to) {
        float tmp = .0f;
        if (to >= from)
            tmp = (float) (from + (Math.random() * (to - from)));
        return tmp;
    }

    public static int createRandomIntBetween(int start, int end) {
        return start + (int) Math.round(Math.random() * (end - start));
    }

    public static String getRandomFromList(List<String> l) {
        return l.get(createRandomIntBetween(0, l.size() - 1));
    }

    public static String getRandomFromArray(String[] a) {
        return a[(createRandomIntBetween(0, a.length - 1))];
    }

    public static String genAddress() {
        return "Test " + Generator.genString(4) + " Avenue, " + Generator.genInt(1, 1000);
    }

    public static long genLong(long from, long to) {
        long tmp = 0;
        if (to >= from)
            tmp = from + Math.round((Math.random() * (to - from)));
        return tmp;
    }

    public static String getRandomFormattedDecimalStringValue(String pattern) {
        Random ran = new Random();
        DecimalFormat df = new DecimalFormat(pattern);
        return String.valueOf(df.format(ran.nextFloat() * 100));
    }
    public static String genIdentificationCode(String day, String month, String year) throws java.text.ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date second = sdf.parse(day+"/"+month+"/"+year);
        Date first = sdf.parse("31/12/1899");
        String amountOfDays = String.valueOf(
                TimeUnit.DAYS.convert(Math.abs(second.getTime() - first.getTime()),TimeUnit.MILLISECONDS));
        String tempValue = amountOfDays+genNumInRange(1000,9999);
        int[] numArray = Arrays.stream(tempValue.split("")).mapToInt(Integer::parseInt).toArray();
        int checkSum = numArray[0] * (-1) + numArray[1] * 5 + numArray[2] * 7 + numArray[3] * 9 + numArray[4] * 4
                + numArray[5] * 6 + numArray[6] * 10 + numArray[7] * 5 + numArray[8] * 7;
        int checkValue = checkSum % 11;
        if(checkValue == 10){
            checkValue = (checkSum % 11) % 10;
        }
        return tempValue + checkValue;
    }
    private static String genNumInRange(int low, int high){
        return String.valueOf(new Random().nextInt(high-low) + low);
    }

    public static User genUser() throws ParseException, java.text.ParseException {
        String validUserNames[] = ParserUserData.getUserData(RandomDataAPIConnector.getData());
        String day = genNumInRange(1,28);
        String month = genNumInRange(1,12);
        String year = genNumInRange(1951,2002);
        return new User(
                validUserNames[1],validUserNames[0],validUserNames[2],genMobilePhone(),
                genEmail(), genIdentificationCode(day,month,year),
                day, month, year, genRandomSerial(),getRandomStringNumber(6));
    }
}
