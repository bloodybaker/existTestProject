package com.creditkasa.core.base;

import com.codeborne.selenide.Selenide;
import com.creditkasa.core.allure.AllureLogger;
import com.creditkasa.core.base.action.*;
import com.creditkasa.core.utils.Constants;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;

import java.util.HashMap;
import java.util.Map;

@Listeners({TestListener.class})
public class BaseTest extends AllureLogger {

    private Map<String, Action> map = new HashMap<String, Action>(){{
       put("opera", new Opera());
       put("chrome", new Chrome());
       put("edge",new Edge());
       put("firefox", new Firefox());
    }};


    @BeforeMethod(alwaysRun = true, description = "Opening web browser...")
    public void setUp(ITestContext context) {
        logInfo("Creating web driver configuration...");
        logInfo("Open browser...");
        logInfo("Navigating to base url - " + Constants.URL + ", instead of base core");
        Selenide.open(Constants.URL);
    }

    @AfterMethod(alwaysRun = true, description = "Closing web browser...")
    public void tearDown() {
        Selenide.closeWebDriver();
        logInfo("Web driver closed!");
    }

    protected void startInBrowser(String browser){
        map.get(browser).startBrowser();
    }
}
