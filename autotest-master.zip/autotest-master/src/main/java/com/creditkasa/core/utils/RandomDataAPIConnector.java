package com.creditkasa.core.utils;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.Objects;

public class RandomDataAPIConnector {
    private static final OkHttpClient httpClient = new OkHttpClient();

    public static String getData(){
        Request request = new Request.Builder().url("https://api.randomdatatools.ru/?gender=man&unescaped=false&params=LastName,FirstName,FatherName").build();
        try(Response response = httpClient.newCall(request).execute()){
            if(response.isSuccessful()){
                return Objects.requireNonNull(response.body()).string();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }
}
