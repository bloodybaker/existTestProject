package com.creditkasa.core.base.action;

public interface Action {
    void startBrowser();
}
