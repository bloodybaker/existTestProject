package com.creditkasa.core.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Constants {
    public static String URL = "https://ukf-portal.test.creditkassa.ua/cabinet/auth/login";
    public static String BACK_OFFICE_URL = "https://bo.ukf-bo.test.creditkassa.ua/security/login";
    public static String LANDING = "https://ukf-client-test.creditkassa.ua/";
    public static String REMOTE_URL = System.getProperty("remoteurl");

    /**
     * Back office credentials
     */

    public static String BACK_LOGIN = "admin";
    public static String BACK_PASSWORD = "5612233";

    /**
     * Banks
     */
    public static String VOSTOK_LOGIN = "+380508132894";
    public static String VOSTOK_PASSWORD = "Qwer1234";
    public static String VOSTOK_OTP = "111111";

    public static String POLIKOM_LOGIN = "ftest1";
    public static String POLIKOM_PASSWORD = "asd";

    public static String PRIVAT_LOGIN = "988489304";
    public static String PRIVAT_PASSWORD = "password9304";

    /**
     * Browsers
     */
    public static String CHROME = "chrome";
    public static String FIREFOX = "firefox";



    public final static ArrayList<String> FILE_FORMATS_FOR_DOWNLOAD = new ArrayList<String>() {{
        add("CSV ");
        add("Quicken (QFX)");
        add("Quickbooks (QBO)");
    }};
    public static String CURRENT_TIME;

    static {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDateTime now = LocalDateTime.now();

        CURRENT_TIME = dtf.format(now);
    }

    public static String BROWSER = System.getProperty("browserName", "chrome");

}