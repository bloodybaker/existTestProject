package com.creditkasa.core.base.action;

import com.creditkasa.core.config.SelenideConfig;

public class Firefox implements Action {
    @Override
    public void startBrowser() {
        SelenideConfig.createBrowserConfig(System.getProperty("selenide.browser", "firefox"));
    }
}
