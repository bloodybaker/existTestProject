package com.creditkasa.entities;

public class User {
    private String firstName;
    private String lastName;
    private String thirdName;
    private String phoneNumber;
    private String email;
    private String identificationCode;
    private String dayOfBirth;
    private String monthOfBirth;
    private String yearOfBirth;
    private String serialValue;
    private String passportNumber;

    public User(String firstName, String lastName, String thirdName, String phoneNumber,
                String email, String identificationCode, String dayOfBirth, String monthOfBitrh,
                String yearOfBirth, String serialValue, String passportNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.thirdName = thirdName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.identificationCode = identificationCode;
        this.dayOfBirth = dayOfBirth;
        this.monthOfBirth = monthOfBitrh;
        this.yearOfBirth = yearOfBirth;
        this.serialValue = serialValue;
        this.passportNumber = passportNumber;
    }

    public String getSerialValue() {
        return serialValue;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getThirdName() {
        return thirdName;
    }

    public void setThirdName(String thirdName) {
        this.thirdName = thirdName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdentificationCode() {
        return identificationCode;
    }

    public void setIdentificationCode(String identificationCode) {
        this.identificationCode = identificationCode;
    }

    public String getDayOfBirth() {
        return dayOfBirth;
    }

    public void setDayOfBirth(String dayOfBirth) {
        this.dayOfBirth = dayOfBirth;
    }

    public String getMonthOfBirth() {
        return monthOfBirth;
    }

    public void setMonthOfBirth(String monthOfBirth) {
        this.monthOfBirth = monthOfBirth;
    }

    public String getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(String yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    @Override
    public String toString() {
        return "User{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", thirdName='" + thirdName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", email='" + email + '\'' +
                ", identificationCode='" + identificationCode + '\'' +
                ", dayOfBirth='" + dayOfBirth + '\'' +
                ", monthOfBirth='" + monthOfBirth + '\'' +
                ", yearOfBirth='" + yearOfBirth + '\'' +
                ", serialValue='" + serialValue + '\'' +
                ", passportNumber='" + passportNumber + '\'' +
                '}';
    }
}
