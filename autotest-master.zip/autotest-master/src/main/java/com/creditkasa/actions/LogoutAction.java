package com.creditkasa.actions;

import com.creditkasa.pages.frontoffice.PagesFront;

public class LogoutAction {

    public void doLogOut(){
        PagesFront.newLoanPage().logout();
    }
}
