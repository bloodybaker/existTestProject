package com.creditkasa.actions;

public class Actions {
    /**
     * Page actions
     */
    private static LogoutAction logoutAction;

    /**
     * This function returns an instance of `LogoutAction`
     */
    public static LogoutAction logoutAction() {
        if (logoutAction == null) {
            logoutAction = new LogoutAction();
        }
        return logoutAction;
    }

}